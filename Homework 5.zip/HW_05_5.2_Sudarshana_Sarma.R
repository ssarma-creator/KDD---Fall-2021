###############################################
#First Name:Sudarshana
#Last Name: Sarma
#CWID: 10469063
#Section: A
#Problem: CART Decision Tree
#Date:10/24/2021
###############################################

rm(list=ls())
file <-  file.choose()
ab <-  read.csv(file,na.strings = "?",colClasses=c("Sample"="character","F1"="factor","F2"="factor","F3"="factor",
                                                     "F4"="factor","F5"="factor","F6"="factor",
                                                     "F7"="factor","F8"="factor","F9"="factor",
                                                     "Class"="factor"))


##Installing the packages
library(rpart)
library(rpart.plot)  			
library(rattle)           
library(RColorBrewer)    

index<-sort(sample(nrow(ab),round(.30*nrow(ab))))
training<-ab[-index,]
test<-ab[index,]
#Grow the tree
CART_class<-rpart( Class~.,data=training[,-1])
rpart.plot(CART_class)
CART_predict2<-predict(CART_class,test, type="class")
df<-as.data.frame(cbind(test,CART_predict2))
table(Actual=test[,"Class"],ab=CART_predict2)

CART_wrong<-sum(test[,"Class"]!=CART_predict2)
CART_wrong
error_rate=CART_wrong/length(test$Class)
error_rate